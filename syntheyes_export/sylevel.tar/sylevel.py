

# Higher-level routines for accessing SynthEyes
#	(c)2012-2015 Andersson Technologies LLC

#  import SyPy
#  hlev = SyPy.SyLevel()
#  hlev.OpenExisting(port, pin)	 	-- talk to existing SynthEyes
#  hlev.OpenSynthEyes(port, pin)	-- create & talk to new SynthEyes
#  hlev.OpenSNI(filenm, port, pin)	-- create SynthEyes, opening filenm
#
# when editing this file:
#    hlev.Close(), reload(sylevel) to re-import it, recreate hlev

__metaclass__ = type  # new style

import sypy
import syobj
import sywin
import symenu
import syconfig
import subprocess
import time

# TODO: fix SynthEyes process to exit properly from remote QUIT
# TODO: Routines to checkboxes and radios, spinners --- for dialogs that aren't in the scene. (Some extant commands...test!)

class SyPrefsIterator:		# all UI-level prefs
    def __init__(self, ahlev):
	# all field names must be in the __setattr_ list!
	self.hlev = ahlev
	self.idx = 0
	self.cnt = self.hlev.NumPrefs()

    def __setattr__(self, atnm, val):
	if atnm in ["hlev", "idx", "cnt"]:
	    self.__dict__[atnm] = val
	else:
	    self.Set(atnm, val)

    def __getattr__(self, atnm):	# so hlev.Prefs().autosave wil work...
	return self.Get(atnm)

    def __iter__(self):
	return self

    def __next__(self):		# python 3.0 compatibility?
	self.next()

    def next(self):
	if self.idx >= self.cnt:
	    raise StopIteration
	ob = syobj.SyPrefObj(self.hlev, self.idx)
	self.idx += 1
	return ob

    def Get(self, nm):		# so hlev.Prefs().Get("autosave") will work...
	return self.hlev.GetPrefFromVar(nm)

    def Set(self, nm, val):
	self.hlev.SetPrefFromVar(nm, val)



class SyActionNameIterator:	# the available action names
    def __init__(self, ahlev):
	self.hlev = ahlev
	self.core = ahlev.core
	self.idx = 0

    def __iter__(self):
	return self

    def __next__(self):		# python 3.0 compatibility?
	self.next()

    def next(self):
	nm = self.core.Run("%d NTHACTIONNAME1" % self.idx)
	if nm == "":
	    raise StopIteration
	self.idx += 1
	return nm


# Limited local state, just convenient thin api stubs on underlying facilities

class SyLevel:
    VF_show_meshes = 1
    VF_double_buffer = 2
    VF_show_3dpts = 4
    VF_show_seeds = 8
    VF_show_solid = 0x10
    VF_show_trackers = 0x20
    VF_show_tracker_pos = 0x40
    VF_show_tracker_err = 0x80
    VF_show_trails = 0x100
    VF_show_image = 0x200
    VF_only_this = 0x400		# only trackers from this object
    VF_show_shadows = 0x800
    VF_only_sel_spline = 0x1000	# only the selected spline
    VF_show_flex = 0x2000
    VF_show_curve = 0x4000
    VF_enable_prefetch = 0x8000		# does NOT directly affect this!
    VF_show_lens_grid = 0x10000
    VF_seed_path = 0x20000		# show seed path of obj, cam
    VF_texture_alpha = 0x40000	# show alpha of texture, not texture
    VF_mesh_hideselect = 0x80000	# hide mesh selection color
    VF_show_outline = 0x100000	# outlining for camera solid view
    VF_show_toon = 0x200000		# "toon" outline for wireframe

    TAFFY_show_alltkname = 0x1		# show all tracker names
    TAFFY_show_tkname = 0x2		# show supv tracker names
    TAFFY_show_seltkname = 0x4		# show selected tracker names
    TAFFY_show_vptnames = 0x8		# show names in 3D viewports also
    TAFFY_show_dot = 0x10		# show trackers dots for all
    TAFFY_only_dot = 0x20		# show tracker dots for all "done" tk
    TAFFY_dots_3D = 0x40		# as dots in 3D view
    TAFFY_dots_persp = 0x80		# as dots in perspective
    TAFFY_alt_color = 0x100		# use alternate colors
    TAFFY_radar = 0x200		# radar display included


    def __init__(self):
	self.core = None
	self.sypath = syconfig.SynthEyesPath()

    def SetCore(self, acore):
	self.core = acore

    def SetPath(self, ovr_path):
	self.sypath = ovr_path

    def OpenSynthEyes(self, port=0, pin=""):	# create new SynthEyes process
	args = self.SynArgList(port, pin)
	subprocess.Popen(args, close_fds=True)
	time.sleep(syconfig.StartTime())
	n = syconfig.RetryCount()
	for i in range(0, n):
	    rv = self.OpenExisting(port, pin)
	    if rv:
		if self.core.debug > 0 and i >  0:
		    print i, "retries to open connection"
		return True
	    time.sleep(syconfig.RetryTime())
	return False

    def OpenSynthEyesWithSNI(self, filenm, port=0, pin=""):
	args = self.SynArgList(port, pin)
	args.append(filenm)
	subprocess.Popen(args, close_fds=True)
	time.sleep(syconfig.StartTime())
	n = syconfig.RetryCount()
	for i in range(0, n):
	    rv = self.OpenExisting(port, pin)
	    if rv:
		if self.core.debug > 0 and i >  0:
		    print i, "retries to open connection"
		return True
	    time.sleep(syconfig.RetryTime())
	return False

    def SynArgList(self, port, pin):
    	if port == 0:
	    port = syconfig.DefaultPort()
	if pin == "":
	    pin = syconfig.DefaultPin()
	xtreme = syconfig.DefaultExtreme()
	args = syconfig.LaunchArgs()
	args.append(self.sypath)
	args.append("-l")
	args.append(str(port))
	args.append("-pin")
	args.append(pin)
	if xtreme != "":
	    args.append("-xt")
	    args.append(xtreme)
	args = syconfig.OptArgs(args)
	return args

    def OpenExisting(self, port=0, pin=""):	# existing SynthEyes process
	self.core = sypy.SyPyCore()
	return self.core.Open(port, pin)	# True/False

    def OpenSNI(self, filnm):		# with EXISTING SynthEyes connection
	self.core.SendS(filnm)
	self.core.SendIdent("OPENSNI1")
	return self.core.Sync()		# 1/0 pass/fail

    def MergeSNI(self, filnm, uni):	# existing SynthEyes connection
	self.core.SendS(filnm)
	self.core.SendI(uni)
	self.core.SendIdent("MERGESNI2")
	return self.core.Sync()		# 1/0 pass/fail

    def SaveIfChanged(self):	# full user interface
	return self.core.Run("SAVEIFCHANGED")

    def CloseSynthEyes(self):
	self.core.Run("QUIT")
	self.core.Close()
	self.core = None

    def Close(self):
	self.core.Close()
	self.core = None

    def Debug(self, v):
	self.core.debug = v

    def Redraw(self):
	self.core.Run("REDRAW")

    def MakeObj(self, ty, idx):
	if idx < 0 and not (ty == "SCENE" or ty == "GLOBAL"):
	    return None
	return syobj.SyObj(self, ty, idx)

# get/set active object

    def Active(self):
	idx = self.core.Run("ACTIVEOBJ")		# this is the index
	return self.MakeObj("OBJ", idx)

    def SetActive(self, sob):
	assert sob.type == "OBJ", "Must be a SynthEyes object"
	self.core.SendI(sob.Index())
	idx = self.core.Run("SETACTIVEOBJ1")

# get/set current frame

    def Frame(self):
	return self.core.Run("FRAME")

    def SetFrame(self, frm):
	self.core.Run("%d SETFRAME1 REDRAW" % frm)

# overrides handled in core level so they can be accessed anywhere

    def SzlFrame(self):
	return self.core.SzlFrame()

    def SetSzlFrame(self, frm):
	self.core.SetSzlFrame(frm)

    def ClearSzlFrame(self):
	self.core.SetSzlFrame(-1)

    def RotOrder(self):
	return self.core.RotOrder()

    def SzlRotOrder(self):
	return self.core.SzlRotOrder()

    def SetSzlRotOrder(self, frm):
	self.core.SetSzlRotOrder(frm)

    def ClearSzlRotOrder(self):
	self.core.SetSzlRotOrder(-1)

    def AxisMode(self):
	return self.core.AxisMode()

    def SzlAxisMode(self):
	return self.core.SzlAxisMode()

    def SetSzlAxisMode(self, frm):
	self.core.SetSzlAxisMode(frm)

    def ClearSzlAxisMode(self):
	self.core.SetSzlAxisMode(-1)

    def SzlRecalc(self):
	return self.core.SzlRecalc()

    def SetSzlRecalc(self, rec):	# 1:recalc, 0: suspend
	self.core.SetSzlRecalc(rec)

    def Conform(self, vecn, veco):      # conform vector to original -> new vec
        if not (isinstance(vecn, list) and len(vecn) == 3):
            raise Exception("1st Conform argument isn't vector")
        if not (isinstance(veco, list) and len(veco) == 3):
            raise Exception("2nd Conform argument isn't vector")
        core = self.core
        core.SendSzl(veco)
        core.SendI(1)               # one argument
        core.SendS("Conform")        # push the function name
        self.SendSzl(vecn)        # the one being conformed
        core.SendIdent("CALLSZLvararg1")
        core.Sync()
        return core.RecvSzl(self.hlev)

# get/set anim start/end

    def AnimStart(self):
	return self.core.Run("ANIMSTART")

    def SetAnimStart(self, frm):
	self.core.SendI(frm)
	self.core.SendIdent("SETANIMSTART1")
	self.core.SendIdent("REDRAW")
	self.core.Sync()

    def AnimEnd(self):
	return self.core.Run("ANIMEND")

    def SetAnimEnd(self, frm):
	self.core.SendI(frm)
	self.core.SendIdent("SETANIMEND1")
	self.core.SendIdent("REDRAW")
	self.core.Sync()

# get/set active object -- fully safe
# get/set sni filename

    def SNIFileName(self):
	return self.core.Run("SNIFILENAME")

    def SetSNIFileName(self, fnm):	# Should be FULL PATH NAME!
	self.core.SendS(fnm)
	self.core.SendIdent("SETSNIFILENAME1")	# includes a SetMainTitle
	self.core.Sync()

# get version, platform etc

    def Version(self):
	return self.core.Run("SEVERSION")

    def Platform(self):
	return self.core.Run("SEPLATFORM")

    def ComputerName(self):
	return self.core.Run("COMPUTERNAME")

    def UserName(self):
	return self.core.Run("USERNAME")

    def AppDir(self):
	return self.core.Run("APPDIR")

    def UserDir(self):
	return self.core.Run("USERDIR")

    def QuitSynthEyes(self):
	self.core.Run("QUIT")

    def MilliSleep(self, millisec):
	self.core.SendI(millisec)
	self.core.SendIdent("MSLEEP1")
	self.core.Sync()

    def Beep(self):
	self.core.Run("BEEP")

# rendershot

    def RenderShot(self, shot):
	self.core.SendI(shot.Index())
	self.core.Run("RENDERSHOT1")		# numeric return code

    def ApplyToTrackers(self, sht, mod):	# Output tab in ImgPrep
	self.core.SendI(sht.Index())
	self.core.SendI(mod)
	self.core.Run("ADJUSTTRACKERS2")

# play/stop, playback rate get/set

    def Play(self):
	self.core.Run("PLAY")

    def Stop(self):
	self.core.Run("STOP")

    def IsPlaying(self):
	return self.core.Run("ISPLAYING")

    def PlaybackRate(self):			# ratio to commanded
	return self.core.Run("PBRATE")

    def SetPlaybackRate(self, rate):			# ratio to commanded
	self.core.SendD(rate)
	self.core.SendIdent("SETPBRATE1")
	self.core.Sync()

# Call Begin/Accept around any Sizzle attribute or direct scene modifications
#	to engage the UNDO system. All such changes MUST be inside an
#	undo block. Other UI operations will create their own undos,
#	they must NOT be inside a Begin/Accept block
# Use the Shot versions below if you will be changing anything about a
#	shot, including the preprocessor settings, that can cause the
#	RAM cache to become invalidated

    def Begin(self):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.InUndo(1)
	self.core.Run("LOCK BEGIN")

    def Continue(self, titl):		# Reenter existing Accept block
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.InUndo(1)
	self.core.SendS(titl)
	self.core.Run("LOCK CONTINUE1")

    def Accept(self, titl):		# Argument is the human undo name
	if self.InUndo() == 0:
	    raise Exception("not in undo")
	self.InUndo(-1)
	self.core.SendS(titl)
	self.core.Run("ACCEPT1 UNLOCK REDRAW")

    def Cancel(self):		# Argument is the human undo name
	if self.InUndo() == 0:
	    raise Exception("not in undo")
	self.InUndo(-1)
	self.core.Run("CANCEL UNLOCK REDRAW")

    def InUndo(self, chg=0):		# reflected to lower level
	return self.core.InUndo(chg)

# Make multiple scene modifications atomic. Locks out the USER and
#	all OTHER Listener threads. SynthEyes will appear to be hung
#	while locked. Do not put complex window operations inside LOCK/UNLOCK

    def Lock(self):
	self.core.Run("LOCK")

    def Unlock(self):
	self.core.Run("UNLOCK")

# BeginShotChanges/AcceptShotChanges -- incl validates

    def BeginShotChanges(self, sht):		# Includes PREVALIDATE
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.InUndo(1)
	self.core.Run("LOCK BEGIN")
	self.PreValidate(sht)

    def BeginStereoChanges(self, lsht, rsht):	# Includes PREVALIDATE
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.InUndo(1)
	self.core.Run("LOCK BEGIN")
	self.PreValidate(lsht)
	self.PreValidate(rsht)

    def AcceptShotChanges(self, sht, titl):	# Includes POSTVALIDATE
	if self.InUndo() == 0:
	    raise Exception("not in undo")
	self.InUndo(-1)
	self.PostValidate(sht)
	self.core.SendS(titl)
	self.core.Run("ACCEPT1 UNLOCK RELOADALL REDRAW")

    def AcceptStereoChanges(self, lsht, rsht, titl):	# Includes POSTVALIDATE
	if self.InUndo() == 0:
	    raise Exception("not in undo")
	self.InUndo(-1)
	self.PostValidate(lsht)
	self.PostValidate(rsht)
	self.core.SendS(titl)
	self.core.Run("ACCEPT1 UNLOCK RELOADALL REDRAW")

    def PreValidate(self, sht):
	si = sht.Index()
	self.core.Run("%d PREVALIDATE1" % si)

    def PostValidate(self, sht):		# does a VALIDATE1 also, ie now
	si = sht.Index()
	self.core.Run("%d POSTVALIDATE1 %d VALIDATE1" % (si, si))

    def Validate(self, sht):
	si = sht.Index()
	self.core.Run("%d VALIDATE1" % si)

    def FlushShot(self, sht):			# not inside Begin/Accept
	si = sht.Index()
	self.core.Run("%d FLUSHSHOT1" % si)

    def ReloadAll(self):
	self.core.Run("RELOADALL")

    def HasChanged(self):
	return self.core.Run("HASCHANGED")

    def ClearChanged(self):
	self.core.Run("CLEARCHANGED")

    def FlushUndo(self):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.core.Run("FLUSHUNDO")

    def Undo(self):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.core.Run("UNDO RELOADALL REDRAW")

    def Redo(self):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.core.Run("REDO RELOADALL REDRAW")

    def UndoCount(self):
	return self.core.Run("UNDOCOUNT")

    def RedoCount(self):
	return self.core.Run("REDOCOUNT")

    def TopUndoName(self):
	return self.core.Run("TOPUNDONAME")

    def TopRedoName(self):
	return self.core.Run("TOPREDONAME")

# Use these routines to set and change the aspect ratio safely

    def SetShotAspect(self, sht, asp):
	self.core.SendI(sht.Index())
	self.core.SendD(asp)
	self.core.Run("SETSHOTASPECT2")

    		# call this AFTER changing aspect, giving it the original
    def ShotAspectChanging(self, sht, original_asp):	# updates splines
	self.core.SendI(sht.Index())
	self.core.SendD(original_asp)
	self.core.Run("ASPECTCHANGING2")

    def ShotSingleImageName(self, sht, frm):	# "" a if movie or bad frm#
	self.core.SendI(sht.Index())
	self.core.SendI(frm)
	self.core.Run("FRAMEIMAGENAME2")

# BeginPref/AcceptPref

    def BeginPref(self):
	if self.InPrefUndo() != 0:
	    raise Exception("already in pref undo")
	self.InPrefUndo(1)
	self.core.Run("LOCK BEGINP")

    def AcceptPref(self):		# NO ARGUMENT NEEDED!
	if self.InPrefUndo() == 0:
	    raise Exception("not in pref undo")
	self.InPrefUndo(-1)
	self.core.Run("ACCEPTP UNLOCK REDRAW ")

    def InPrefUndo(self, chg=0):		# reflected to lower level
	return self.core.InPrefUndo(chg)

    def NumPrefs(self):
	return self.core.Run("UIPREFCNT");

    def PrefVariable(self, idx):	# the attribute name Prefs.Get(...)
	return self.core.Run("%d UIPREFVAR1" % idx);

    def PrefName(self, idx):		# user-visible preference name
	return self.core.Run("%d UIPREFNM1" % idx);

    def PrefIndex2PrefScene(self, idx):	# index in actual Prefs scene
	return self.core.Run("%d UIPREFID1" % idx);

    def PrefDescription(self, idx):	# description tooltip
	return self.core.Run("%d UIPREFDESC1" % idx);

    def FindPrefFromVariable(self, prefnm):
	self.core.SendS(prefnm)
	return self.core.Run("FINDUIPREFVAR1")

    def FindPrefFromName(self, descr):
	self.core.SendS(descr)
	return self.core.Run("FINDUIPREFNM1")

    def GetPrefFromIndex(self, idx):
	sidx = self.PrefIndex2PrefScene(idx)
	self.core.SendI(sidx)
	return self.core.Run("GETP1")	#

    def GetPrefFromName(self, nm):
	self.core.SendS(nm)
	idx = self.core.Run("FINDUIPREFNM1")
	if idx < 0:
	    return None
	return self.GetPrefFromIndex(idx)

    def GetPrefFromVar(self, nm):
	self.core.SendS(nm)
	idx = self.core.Run("FINDUIPREFVAR1")
	if idx < 0:
	    return None
	return self.GetPrefFromIndex(idx)

    def SetPrefFromIndex(self, idx, val):
	if self.core.InPrefUndo() == 0:
	    raise Exception("not in prefs undo")
	sidx = self.PrefIndex2PrefScene(idx)
	self.core.SendI(sidx)
	if isinstance(val, int):
	    self.core.SendI(val)
	elif isinstance(val, float):
	    self.core.SendD(val)
	elif isinstance(val, str):
	    self.core.SendS(val)
	else:
	    raise Exception("bad pref type")
	self.core.Run("SETP2")

    def SetPrefFromName(self, nm, val):
	self.core.SendS(nm)
	idx = self.core.Run("FINDUIPREFNM1")
	if idx < 0:
	    return False
	self.SetPrefFromIndex(idx, val)
	return True

    def SetPrefFromVar(self, nm, val):
	self.core.SendS(nm)
	idx = self.core.Run("FINDUIPREFVAR1")
	if idx < 0:
	    return False
	self.SetPrefFromIndex(idx, val)
	return True

# folder prefs --- see the preferences panel for listing
# BATCHIN/BATCHOUT/IMAGE/SCENE/IMPORT/EXPORT/PREVIEW/SCRIPT

    def FolderPref(self, pnm):
	self.core.SendIdent("PREF_FOLDER");
	self.core.SendIdent("PREF_FOLDER_" + pnm.upper())
	return self.core.Run("GETP2")

    def SetFolderPref(self, pnm, fnm):
	self.core.SendIdent("PREF_FOLDER")
	self.core.SendIdent("PREF_FOLDER_" + pnm.upper())
	self.core.SendS(fnm)
	return self.core.Run("SETP3")

# New shot/addshot (stereo)

    def NewSceneAndShot(self, filnm, asp = 0.0):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.core.SendS(filnm)
	self.core.SendD(asp)
	rv = self.core.Run("NEWSHOT2")	# rv 1/0 for pass/fail
	if rv == 0:
	    return None
	return self.MakeObj("SHOT", 0)

    def NewSceneAndStereoShot(self, Lfilnm, Rfilnm, asp = 0.0):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.core.SendS(Lfilnm)
	self.core.SendS(Rfilnm)
	self.core.SendD(asp)
	rv = self.core.Run("NEWSTEREO3")	# rv 1/0 for pass/fail
	if rv == 0:
	    return None
	return self.MakeObj("SHOT", 0)

    def AddShot(self, filnm, asp = 0.0):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	ns = self.NumByType("SHOT")
	self.core.SendS(filnm)
	self.core.SendD(asp)
	rv = self.core.Run("ADDSHOT2")	# rv 1/0 for pass/fail
	if rv == 0:
	    return None
	return self.MakeObj( "SHOT", ns)

    def AddStereoShot(self, Lfilnm, Rfilnm, asp = 0.0):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	ns = self.NumByType("SHOT")
	self.core.SendS(Lfilnm)
	self.core.SendS(Rfilnm)
	self.core.SendD(asp)
	rv = self.core.Run("ADDSTEREO3")	# rv 1/0 for pass/fail
	if rv == 0:
	    return None
	return self.MakeObj( "SHOT", ns)

# New survey/add survey

    def NewSceneAndSurveyShot(self, iflnm, asp = 0.0):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	self.core.SendS(iflnm)
	self.core.SendD(asp)
	rv = self.core.Run("NEWSHOT2")	# rv 1/0 for pass/fail
	if rv == 0:
	    return None
	self.Begin()
	sht = self.MakeObj( "SHOT", 0)
	sht.Set("isSurvey", 1)
	self.Accept("Set as survey")
	return sht

    def AddSurveyShot(self, iflnm, asp = 0.0):
	if self.InUndo() != 0:
	    raise Exception("already in undo")
	ns = self.NumByType("SHOT")
	self.core.SendS(iflnm)
	self.core.SendD(asp)
	rv = self.core.Run("ADDSHOT2")	# rv 1/0 for pass/fail
	if rv == 0:
	    return None
	self.Begin()
	sht = self.MakeObj( "SHOT", ns)
	sht.Set("isSurvey", 1)
	self.Accept("Set as survey")
	return sht

# Get Shots, Trackers, Objects, Cameras, Meshes

    def CreateNew(self, ty):
	if not (ty == "MESH" or ty == "LIGHT" or ty == "OBJ" or ty == "NOTE"):
	    raise Exception("use different routine for this")
	self.core.SendS(ty)
	idx = self.core.Run("CREATENEWSZLvar")
	return self.MakeObj(ty, idx)

    def CreateNewTracker(self, ob):
	self.core.SendI(ob.Index())
	self.core.SendS("TRK")
	idx = self.core.Run("CREATENEWSZLvar")
	return self.MakeObj("TRK", idx)

    def CreateNewPhase(self, phty):
	self.core.SendI(phty)
	self.core.SendS("PHASE")
	idx = self.core.Run("CREATENEWSZLvar")
	return self.MakeObj("PHASE", idx)

    def Delete(self, ob):
	self.core.SendSzl(ob)
	self.core.Run("DELETESZL2")

    def NumByType(self, ty):
	if ty == "SCENE":
	    return 1
	elif ty == "GLOBAL":
	    return 1
	elif ty == "SHOT" or ty == "STER":
	    v = 1
	elif ty == "TRK":
	    v = 2
	elif ty == "OBJ":
	    v = 3
	elif ty == "MESH":
	    v = 4
	elif ty == "EXTRA":
	    v = 5
	elif ty == "LIGHT":
	    v = 6
	elif ty == "SPLINE":
	    v = 8
	elif ty == "STOREPREP":
	    v = 10
	elif ty == "PHASE":
	    v = 14
	elif ty == "NOTE":
	    v = 15
	else:
	    return 0
	self.core.SendI(v)
	return self.core.Run("COUNT1")

    def Scene(self):			# one SyObj
	return self.MakeObj( "SCENE", 0)

    def Globals(self):			# one SyObj
	return self.MakeObj( "GLOBAL", 0)

    def Prefs(self):			# Iterator & attribute-name access
	return SyPrefsIterator(self)

    def ListOf(self, ty):
    	obl = []
	n = self.NumByType(ty)
	for idx in range(0, n):
	    obl.append(self.MakeObj(ty, idx))
	return obl

    def Shots(self):
	return self.ListOf("SHOT")

    def Objects(self):
	return self.ListOf("OBJ")

    def Cameras(self):
	caml = []
	for ob in self.Objects():
	    if ob.Get("isCamera") != 0:
		caml.append(ob)
	return caml

    def Trackers(self):
	return self.ListOf("TRK")

    def Meshes(self):
	return self.ListOf("MESH")
    def Lights(self):
	return self.ListOf("LIGHT")
    def Extras(self):
	return self.ListOf("EXTRA")
    def Notes(self):
	return self.ListOf("NOTE")

    def ReadOBJ(self, filnm):		# read NEW mesh
	if self.InUndo() == 0:
	    raise Exception("not in undo")
	self.core.SendS(filnm)
	self.core.SendI(-1)
	mi = self.core.Run("READOBJ2")
	return self.MakeObj("MESH", mi)	# will be None if failed

# object selection

    def ClearSelection(self):		# single, tracker, and mesh selects
	self.core.Run("CLEARSELECTION")

    def SelectedTrackers(self):		# Always CURRENT object
	cnt = self.core.Run("NUMSELTRK")
	obl = []
	for idx in range(cnt):
	    ti = self.core.Run("%d NTHSELTRK1" % idx)
	    obl.append(self.MakeObj("TRK", ti))
	return obl

    def SelectedMeshes(self):		# In entire scene
	cnt = self.core.Run("NUMSELMESH")
	obl = []
	for idx in range(cnt):
	    mi = self.core.Run("%d NTHSELMESH1" % idx)
	    obl.append(self.MakeObj("MESH", mi))
	return obl

    def SelectedObject(self):		# if ONLY ONE! See isSelected attrs
	scn = self.Scene()
	return scn.Get("selected")

    def Select1Object(self, obj): # Clear, select ONE! See isSelected attrs
	scn = self.Scene()
	return scn.Set("selected", obj)

# find Obj/Tracker/... by name (w/stubs for usual suspects)
# TODO: check if PHASE is supported for this cmd also

    def FindByName(self, ty, nm):
	if ty == "TRK" or ty == "OBJ" or ty == "MESH" or ty == "LIGHT" or ty == "EXTRA" or ty == "NOTE":
	    self.core.SendS(nm)
	    self.core.SendS(ty)
	    idx = self.core.Run("FINDIDXBYNAME2")
	    return self.MakeObj(ty, idx)
			# Hmmm, have to do it the hard way
	cnt = self.NumByType(ty)
	for i in range(0, cnt):
	    ob = self.MakeObj(ty, i)
	    if ob.Name() == nm:
		return ob
	return None

    def FindObjByName(self, nm):
	return self.FindByName("OBJ", nm)

    def FindTrackerByName(self, nm):
	return self.FindByName("TRK", nm)

    def FindTrackerOnObjectByName(self, ob, nm):
	self.core.SendI(ob.Index())
	self.core.SendS(nm)
	self.core.SendS("TRKOBJ")
	idx = self.core.Run("FINDIDXBYNAME2")
	return self.MakeObj("TRK", idx)

    def FindMeshByName(self, nm):
	return self.FindByName("MESH", nm)

# Get/set viewport configuration

    def View(self):
	return self.core.Run("VIEW")	# string name of the current room

    def SetView(self, viewnm):
	self.core.SendS(viewnm)
	self.core.SendIdent("SETVIEW1")
	self.core.Sync()

    def SetRoomWithView(self, viewnm):
	self.core.SendS(viewnm)
	self.core.SendIdent("SETROOMWITHVIEW1")
	self.core.Sync()

# new room controls in listener for ROOM, SETROOM1 by name

    def Room(self):
	return self.core.Run("ROOM")	# string name of the current room

    def SetRoom(self, roomnm):
	self.core.SendS(roomnm)
	self.core.SendIdent("SETROOM1")
	self.core.Sync()

# Programmatic export control

    def Export(self, exportType, exportFile):
	self.ConfigureExport(exportType, exportFile)
	self.ExportAgain()

    def ConfigureExport(self, exportType, exportFile):
	self.Begin()
	scn = self.MakeObj( "SCENE", -1)	# modify scene attr
	scn.Set("exportType", exportType)
	scn.Set("exportFile", exportFile)
	self.Accept("Configure Export")

    def ExportAgain(self):
	self.ClickMainMenuAndWait("Export Again")

    def ExportMultiple(self):
	self.ClickMainMenuAndWait("Export Multiple")

# Window accessors

    def Main(self):
	return sywin.SyWin(self, "MAINWINDOW")	# self is the hlev!
    def Popup(self):
	return sywin.SyWin(self, "POPUPWINDOW")	# self is the hlev!
    def Status(self):
	return sywin.SyWin(self, "STATUSWINDOW")	# self is the hlev!
    def Floating(self, wtitl):
	self.core.SendS(wtitl)
	return sywin.SyWin(self, "FLOATINGWINDOW1")	# self is the hlev!

# Menu accessors

    def MainMenu(self):
    	return symenu.SyMenu(self, "TOPMENU")	# self is the hlev!
    def TopMenu(self, nm):
    	return symenu.SyMenu(self, "%s FINDTOPMENU1" % self.core.EncodeS(nm))

# Click menu item given by the bare name, ie "Add Shot", NOT "Shot/Add Shot"
# The item name must be, and usually is, unique.
# The Main versions look in the overall main menu
# The Top versions look in the specified top-level menu
# In either case, recursive search for that name at any depth
# The AndWait versions don't return until the operation completes, ie waiting
#	out any required user interaction on any dialogs that pop up
# The AndContinue versions return immediately, so any dialog can be driven by
#	remote control from python

    def ClickMainMenuAndWait(self, itemnm):	 # the bare name "Add Shot"
	self.core.SendIdent("TOPMENU")
	self.intClickMenu(itemnm, "CLICKMENUID1")

    def ClickMainMenuAndContinue(self, itemnm):	 # the bare name "Add Shot"
	self.core.SendIdent("TOPMENU")
	self.intClickMenu(itemnm, "PCLICKMENUID1")

    def ClickTopMenuAndWait(self, topnm, itemnm):	# ie "Shot", "Add Shot"
	self.core.SendS(topnm)
	self.core.SendIdent("FINDTOPMENU1")
	self.intClickMenu(itemnm, "CLICKMENUID1")

    def ClickTopMenuAndContinue(self, topnm, itemnm):	# ie "Shot", "Add Shot"
	self.core.SendS(topnm)
	self.core.SendIdent("FINDTOPMENU1")
	self.intClickMenu(itemnm, "PCLICKMENUID1")

    def intClickMenu(self, itemnm, lastcmd):	# menu on stack coming in
	self.core.SendS(itemnm)
	self.core.SendIdent("MENUIDBYNAMEREC2")
	if self.core.Run("DUPL1 RETRIEVE1") == 0:
	    self.core.Run("POP1")
	    raise Exception("Menu not found")
	self.core.SendIdent(lastcmd)
	self.core.Sync()

    def InitMenu(self):		# updates menu based on current status
	self.core.Run("INITMENU")

    def FindNewScripts(self):	# look for anything new
	self.ClickTopMenuAndWait("File", "Find new scripts")

# Actions

    def Actions(self):
	return SyActionNameIterator(self)

    def ActionID(self, nm):
	self.core.SendS(nm)
	return self.core.Run("FINDACTIONID1 RETRIEVE1")

    def PerformActionByNameAndWait(self, nm):
	self.core.SendS(nm)
	self.core.Run("FINDACTIONID1 CLICKMENUID1")

    def PerformActionByNameAndContinue(self, nm):
	self.core.SendS(nm)
	self.core.Run("FINDACTIONID1 PCLICKMENUID1")

    def PerformActionByIDAndWait(self, idno):
	# don't check idno, can be an action id
	self.core.SendI(idno)
	self.core.Run("CLICKMENUID1")

    def PerformActionByIDAndContinue(self, idno):
	# don't check idno, can be an action id
	self.core.SendI(idno)
	self.core.Run("PCLICKMENUID1")

# Flag support

    def ViewFlags(self, set=0, clr=0):
	ov = self.core.Run("GETVF")
	self.core.SendI(clr)
	self.core.SendIdent("CLEARVF1")
	self.core.SendI(set)
	self.core.SendIdent("SETVF1")
	self.core.Run("REDRAW")
	return ov

    def TrackerFlags(self, set=0, clr=0):
	ov = self.core.Run("GETTAF")
	self.core.SendI(clr)
	self.core.SendIdent("CLEARTAF1")
	self.core.SendI(set)
	self.core.SendIdent("SETTAF1")
	self.core.Run("REDRAW")
	return ov
